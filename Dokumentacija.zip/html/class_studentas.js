var class_studentas =
[
    [ "Studentas", "class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539", null ],
    [ "~Studentas", "class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23", null ],
    [ "Studentas", "class_studentas.html#a1fd845711ed6febce56596daef79910b", null ],
    [ "getEgzaminas", "class_studentas.html#abe38c118e8e899b4de681f1d12adceab", null ],
    [ "getFinalMediana", "class_studentas.html#a8c684e8d07406b16b07748ccc1b4d06b", null ],
    [ "getFinalVidurkis", "class_studentas.html#ae69d93aeac76cb73cb5ef7eccc010074", null ],
    [ "getPavarde", "class_studentas.html#a5dd7dab43d87cee10ce8b65851adb046", null ],
    [ "getVardas", "class_studentas.html#a7658f22795330130632ac24769a2fd43", null ],
    [ "operator!=", "class_studentas.html#a1bcb9b8fb4511baa1e33c6ae73aa8200", null ],
    [ "operator<", "class_studentas.html#a2332fa5ab27eb3e422cb0c1faa4ab3da", null ],
    [ "operator=", "class_studentas.html#a9e0446a4f32138ec6143484ced181673", null ],
    [ "operator==", "class_studentas.html#a2929aa25e7fe2b9605a6487f1c69935b", null ],
    [ "operator>", "class_studentas.html#ae9e8082f62b0b482acc9726249a7c0fd", null ],
    [ "setEgzaminas", "class_studentas.html#a78c983307578dda3b4bdb988c1342793", null ],
    [ "setND", "class_studentas.html#aa54ec3b1d97b91b303f8e17c6126565f", null ],
    [ "setPavarde", "class_studentas.html#a33f351b1ef09f33cc1d5d54ce36524f1", null ],
    [ "setVardas", "class_studentas.html#ac78bbac0ceb23b47b7c11eee40d95069", null ],
    [ "skaiciavimas", "class_studentas.html#aeffed3917c2fcfa19979e625aa9b9cb1", null ]
];