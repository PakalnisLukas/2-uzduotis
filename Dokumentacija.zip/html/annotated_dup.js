var annotated_dup =
[
    [ "Person", "class_person.html", "class_person" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ]
];