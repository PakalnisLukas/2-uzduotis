var hierarchy =
[
    [ "Person", "class_person.html", [
      [ "Studentas", "class_studentas.html", null ]
    ] ]
];