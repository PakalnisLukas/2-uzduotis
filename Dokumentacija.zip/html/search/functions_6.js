var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../class_studentas.html#a78c983307578dda3b4bdb988c1342793',1,'Studentas']]],
  ['setnd_1',['setND',['../class_studentas.html#aa54ec3b1d97b91b303f8e17c6126565f',1,'Studentas']]],
  ['setpavarde_2',['setPavarde',['../class_person.html#afd8b50e2a5d877f8f450388448b591d6',1,'Person::setPavarde()'],['../class_studentas.html#a33f351b1ef09f33cc1d5d54ce36524f1',1,'Studentas::setPavarde()']]],
  ['setvardas_3',['setVardas',['../class_person.html#a7f434b279bfe3778d46a552684bdf3b0',1,'Person::setVardas()'],['../class_studentas.html#ac78bbac0ceb23b47b7c11eee40d95069',1,'Studentas::setVardas()']]],
  ['skaiciai_4',['Skaiciai',['../biblioteka_8h.html#ae04b136b40bfaa85c815e2db86a1eafb',1,'biblioteka.h']]],
  ['skaiciavimai_5',['Skaiciavimai',['../biblioteka_8h.html#a89cf5e578b1205d0b8e28293bed01b24',1,'Skaiciavimai(vector&lt; Studentas &gt; &amp;Stud):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#a89cf5e578b1205d0b8e28293bed01b24',1,'Skaiciavimai(vector&lt; Studentas &gt; &amp;Stud):&#160;funkcijos.cpp']]],
  ['skaiciavimas_6',['skaiciavimas',['../class_studentas.html#aeffed3917c2fcfa19979e625aa9b9cb1',1,'Studentas']]],
  ['spausdinimas_7',['Spausdinimas',['../biblioteka_8h.html#a4d9055c5876bd56b5f06ab6f958ea0cb',1,'Spausdinimas(vector&lt; Studentas &gt; &amp;Stud, int t, string text):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#a4d9055c5876bd56b5f06ab6f958ea0cb',1,'Spausdinimas(vector&lt; Studentas &gt; &amp;Stud, int t, string text):&#160;funkcijos.cpp']]],
  ['studentas_8',['Studentas',['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#a1fd845711ed6febce56596daef79910b',1,'Studentas::Studentas(const Studentas &amp;)']]]
];
