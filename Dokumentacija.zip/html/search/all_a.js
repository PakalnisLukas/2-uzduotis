var searchData=
[
  ['_7eperson_0',['~Person',['../class_person.html#a700ffd693321c5fe6880262acf43d4da',1,'Person']]],
  ['_7estudentas_1',['~Studentas',['../class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23',1,'Studentas']]]
];
