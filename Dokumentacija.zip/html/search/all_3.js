var searchData=
[
  ['ivedimas_0',['Ivedimas',['../biblioteka_8h.html#a1c5df02e2c236199dbdcf53eac114218',1,'Ivedimas(vector&lt; Studentas &gt; &amp;Stud):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#a1c5df02e2c236199dbdcf53eac114218',1,'Ivedimas(vector&lt; Studentas &gt; &amp;Stud):&#160;funkcijos.cpp']]]
];
