var searchData=
[
  ['studentas_0',['Studentas',['../class_studentas.html',1,'']]]
];
