var searchData=
[
  ['vardas_5f_0',['Vardas_',['../class_person.html#a65937870b30575473501ce7f0238b653',1,'Person']]]
];
