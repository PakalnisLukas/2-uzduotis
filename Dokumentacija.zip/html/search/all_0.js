var searchData=
[
  ['biblioteka_2eh_0',['biblioteka.h',['../biblioteka_8h.html',1,'']]]
];
