var searchData=
[
  ['generavimas_0',['Generavimas',['../biblioteka_8h.html#a80732db2facf980c93a366d9cf684207',1,'Generavimas(std::size_t i):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#a80732db2facf980c93a366d9cf684207',1,'Generavimas(std::size_t i):&#160;funkcijos.cpp']]],
  ['generavimasoutputfiles_1',['GeneravimasOutputFiles',['../biblioteka_8h.html#ab5f45c1740f8b79def3e24a0696134c5',1,'GeneravimasOutputFiles(vector&lt; Studentas &gt; &amp;Stud, vector&lt; Studentas &gt; &amp;Neigiami, vector&lt; Studentas &gt; &amp;Teigiami, int t):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#ab5f45c1740f8b79def3e24a0696134c5',1,'GeneravimasOutputFiles(vector&lt; Studentas &gt; &amp;Stud, vector&lt; Studentas &gt; &amp;Neigiami, vector&lt; Studentas &gt; &amp;Teigiami, int t):&#160;funkcijos.cpp']]],
  ['getegzaminas_2',['getEgzaminas',['../class_studentas.html#abe38c118e8e899b4de681f1d12adceab',1,'Studentas']]],
  ['getfinalmediana_3',['getFinalMediana',['../class_studentas.html#a8c684e8d07406b16b07748ccc1b4d06b',1,'Studentas']]],
  ['getfinalvidurkis_4',['getFinalVidurkis',['../class_studentas.html#ae69d93aeac76cb73cb5ef7eccc010074',1,'Studentas']]],
  ['getpavarde_5',['getPavarde',['../class_person.html#a099b839ca5380ef97e0129e3bdb54155',1,'Person::getPavarde()'],['../class_studentas.html#a5dd7dab43d87cee10ce8b65851adb046',1,'Studentas::getPavarde()']]],
  ['getvardas_6',['getVardas',['../class_person.html#a042f652c5211251c6ac07271407fa7d1',1,'Person::getVardas()'],['../class_studentas.html#a7658f22795330130632ac24769a2fd43',1,'Studentas::getVardas()']]]
];
