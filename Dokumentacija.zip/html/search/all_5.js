var searchData=
[
  ['neigiami1_0',['Neigiami1',['../biblioteka_8h.html#ae2e408fda59f5b018c72d4ccd02e7479',1,'Neigiami1(Studentas &amp;Stud):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#ae2e408fda59f5b018c72d4ccd02e7479',1,'Neigiami1(Studentas &amp;Stud):&#160;funkcijos.cpp']]],
  ['neigiami2_1',['Neigiami2',['../biblioteka_8h.html#af3d63e9e1dc5138dd2b0521ecd4a0026',1,'Neigiami2(Studentas &amp;Stud):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#af3d63e9e1dc5138dd2b0521ecd4a0026',1,'Neigiami2(Studentas &amp;Stud):&#160;funkcijos.cpp']]],
  ['nuskaitymas_2',['Nuskaitymas',['../biblioteka_8h.html#abd8bcd6ce87a79f0fe8ecaa786662971',1,'Nuskaitymas(vector&lt; Studentas &gt; &amp;Stud, string filename):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#abd8bcd6ce87a79f0fe8ecaa786662971',1,'Nuskaitymas(vector&lt; Studentas &gt; &amp;Stud, string filename):&#160;funkcijos.cpp']]]
];
