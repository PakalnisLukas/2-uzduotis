var biblioteka_8h =
[
    [ "Person", "class_person.html", "class_person" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "Generavimas", "biblioteka_8h.html#a80732db2facf980c93a366d9cf684207", null ],
    [ "GeneravimasOutputFiles", "biblioteka_8h.html#ab5f45c1740f8b79def3e24a0696134c5", null ],
    [ "Ivedimas", "biblioteka_8h.html#a1c5df02e2c236199dbdcf53eac114218", null ],
    [ "Neigiami1", "biblioteka_8h.html#ae2e408fda59f5b018c72d4ccd02e7479", null ],
    [ "Neigiami2", "biblioteka_8h.html#af3d63e9e1dc5138dd2b0521ecd4a0026", null ],
    [ "Nuskaitymas", "biblioteka_8h.html#abd8bcd6ce87a79f0fe8ecaa786662971", null ],
    [ "Pasirinkimas", "biblioteka_8h.html#ab0d8066755e9c9ca8230a98f47824fcb", null ],
    [ "Skaiciai", "biblioteka_8h.html#ae04b136b40bfaa85c815e2db86a1eafb", null ],
    [ "Skaiciavimai", "biblioteka_8h.html#a89cf5e578b1205d0b8e28293bed01b24", null ],
    [ "Spausdinimas", "biblioteka_8h.html#a4d9055c5876bd56b5f06ab6f958ea0cb", null ]
];