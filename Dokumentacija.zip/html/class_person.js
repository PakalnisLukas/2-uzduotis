var class_person =
[
    [ "Person", "class_person.html#ad7362af8633a65037a31afb045578bff", null ],
    [ "Person", "class_person.html#a0397c6f89fafc12e738923f612bc41a3", null ],
    [ "~Person", "class_person.html#a700ffd693321c5fe6880262acf43d4da", null ],
    [ "getPavarde", "class_person.html#a099b839ca5380ef97e0129e3bdb54155", null ],
    [ "getVardas", "class_person.html#a042f652c5211251c6ac07271407fa7d1", null ],
    [ "setPavarde", "class_person.html#afd8b50e2a5d877f8f450388448b591d6", null ],
    [ "setVardas", "class_person.html#a7f434b279bfe3778d46a552684bdf3b0", null ],
    [ "Pavarde_", "class_person.html#aa8dec75422967b1c3374f498b7bdf548", null ],
    [ "Vardas_", "class_person.html#a65937870b30575473501ce7f0238b653", null ]
];